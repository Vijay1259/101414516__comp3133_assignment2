import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GraphqlService } from '../services/graphql.service';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="container mt-5">
      <h2>Employees</h2>
      <input class="form-control mb-3" placeholder="Search by Department" [(ngModel)]="department" (ngModelChange)="search()" />
      <input class="form-control mb-3" placeholder="Search by Position" [(ngModel)]="position" (ngModelChange)="search()" />
      <table class="table table-bordered table-hover">
        <thead><tr><th>Name</th><th>Email</th><th>Dept</th><th>Position</th><th>Salary</th><th>Actions</th></tr></thead>
        <tbody>
          <tr *ngFor="let emp of employees">
            <td>{{ emp.name }}</td><td>{{ emp.email }}</td><td>{{ emp.department }}</td>
            <td>{{ emp.position }}</td><td>{{ emp.salary }}</td>
            <td>
              <button class="btn btn-sm btn-info" (click)="edit(emp.id)">Edit</button>
              <button class="btn btn-sm btn-danger" (click)="remove(emp.id)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `
})
export class EmployeeListComponent implements OnInit {
  employees: any[] = [];
  department = '';
  position = '';

  constructor(private gql: GraphqlService, private router: Router) {}

  ngOnInit() {
    this.load();
  }

  load() {
    this.gql.getEmployees().subscribe((res: any) => this.employees = res.data.employees);
  }

  search() {
    this.gql.searchEmployees(this.department, this.position).subscribe((res: any) => {
      this.employees = res.data.searchEmployees;
    });
  }

  edit(id: string) {
    this.router.navigate(['/edit-employee', id]);
  }

  remove(id: string) {
    if (confirm('Are you sure?')) {
      this.gql.deleteEmployee(id).subscribe(() => this.load());
    }
  }
} 
