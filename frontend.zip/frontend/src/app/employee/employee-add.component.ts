import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GraphqlService } from '../services/graphql.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-employee-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <h2>Add Employee</h2>
      <form (ngSubmit)="save()">
        <input class="form-control mb-2" placeholder="Name" [(ngModel)]="emp.name" name="name" required />
        <input class="form-control mb-2" placeholder="Email" [(ngModel)]="emp.email" name="email" required />
        <input class="form-control mb-2" placeholder="Department" [(ngModel)]="emp.department" name="department" required />
        <input class="form-control mb-2" placeholder="Position" [(ngModel)]="emp.position" name="position" required />
        <input class="form-control mb-2" placeholder="Salary" [(ngModel)]="emp.salary" name="salary" type="number" required />
        <input type="file" class="form-control mb-2" (change)="upload($event)" />
        <button class="btn btn-success" type="submit">Save</button>
      </form>
    </div>
  `
})
export class EmployeeAddComponent {
  emp: any = {};

  constructor(private gql: GraphqlService, private router: Router) {
    const token = sessionStorage.getItem('token');
    if (!token) {
      console.warn('Not logged in – redirecting to login');
      this.router.navigate(['/']);
    }
  }

  upload(event: any) {
    const file = event.target.files[0];
    const form = new FormData();
    form.append('file', file);
    fetch('http://localhost:4000/upload', { method: 'POST', body: form })
      .then(res => res.json())
      .then(data => this.emp.profile = data.filename);
  }

  save() {
    this.gql.addEmployee(this.emp).subscribe(() => {
      this.router.navigate(['/employees']);
    });
  }
}