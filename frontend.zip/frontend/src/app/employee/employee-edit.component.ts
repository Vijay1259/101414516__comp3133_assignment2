import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GraphqlService } from '../services/graphql.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-employee-edit',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <h2>Edit Employee</h2>
      <form (ngSubmit)="save()">
        <input class="form-control mb-2" placeholder="Name" [(ngModel)]="emp.name" name="name" required />
        <input class="form-control mb-2" placeholder="Email" [(ngModel)]="emp.email" name="email" required />
        <input class="form-control mb-2" placeholder="Department" [(ngModel)]="emp.department" name="department" required />
        <input class="form-control mb-2" placeholder="Position" [(ngModel)]="emp.position" name="position" required />
        <input class="form-control mb-2" placeholder="Salary" [(ngModel)]="emp.salary" name="salary" type="number" required />
        <input type="file" class="form-control mb-2" (change)="upload($event)" />
        <button class="btn btn-primary" type="submit">Update</button>
      </form>
    </div>
  `
})
export class EmployeeEditComponent implements OnInit {
  emp: any = {};
  id = '';

  constructor(private route: ActivatedRoute, private gql: GraphqlService, private router: Router) {}

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.gql.getEmployee(this.id).subscribe((res: any) => this.emp = res.data.employee);
  }

  upload(event: any) {
    const file = event.target.files[0];
    const form = new FormData();
    form.append('file', file);
    fetch('http://localhost:4000/upload', { method: 'POST', body: form })
      .then(res => res.json())
      .then(data => this.emp.profile = data.filename);
  }

  save() {
    this.gql.updateEmployee({ ...this.emp, id: this.id }).subscribe(() => this.router.navigate(['/employees']));
  }
} 
