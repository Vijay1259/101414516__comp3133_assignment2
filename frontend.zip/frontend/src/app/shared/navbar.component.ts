import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SessionService } from '../services/session.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" routerLink="/employees">Employee Manager</a>
        <div class="collapse navbar-collapse">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0" *ngIf="loggedIn">
            <li class="nav-item"><a class="nav-link" routerLink="/add-employee">Add Employee</a></li>
            <li class="nav-item"><a class="nav-link" (click)="logout()">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>
  `
})
export class NavbarComponent {
  get loggedIn() {
    return SessionService.isLoggedIn();
  }

  logout() {
    SessionService.logout();
    location.href = "/";
  }
} 
