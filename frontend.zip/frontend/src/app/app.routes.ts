import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', loadComponent: () => import('./auth/login.component').then(m => m.LoginComponent) },
  { path: 'signup', loadComponent: () => import('./auth/signup.component').then(m => m.SignupComponent) },
  { path: 'employees', loadComponent: () => import('./employee/employee-list.component').then(m => m.EmployeeListComponent) },
  { path: 'add-employee', loadComponent: () => import('./employee/employee-add.component').then(m => m.EmployeeAddComponent) },
  { path: 'edit-employee/:id', loadComponent: () => import('./employee/employee-edit.component').then(m => m.EmployeeEditComponent) },
  // Optionally, set a default route like this
  { path: '**', redirectTo: '' }  // This acts as a catch-all route for undefined paths
];
