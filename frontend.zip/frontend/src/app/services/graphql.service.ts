import { Injectable } from '@angular/core';
import { Apollo, gql } from 'apollo-angular';

@Injectable({ providedIn: 'root' })
export class GraphqlService {
  constructor(private apollo: Apollo) {}

  getEmployees() {
    return this.apollo.watchQuery({
      query: gql`{ employees { id name email department position salary profile } }`
    }).valueChanges;
  }

  getEmployee(id: string) {
    return this.apollo.query({
      query: gql`query ($id: ID!) { employee(id: $id) { id name email department position salary profile } }`,
      variables: { id }
    });
  }

  addEmployee(emp: any) {
    return this.apollo.mutate({
      mutation: gql`
        mutation ($name: String!, $email: String!, $department: String!, $position: String!, $salary: Float!, $profile: String) {
          addEmployee(name: $name, email: $email, department: $department, position: $position, salary: $salary, profile: $profile) {
            id
          }
        }
      `,
      variables: emp
    });
  }

  updateEmployee(emp: any) {
    return this.apollo.mutate({
      mutation: gql`
        mutation ($id: ID!, $name: String!, $email: String!, $department: String!, $position: String!, $salary: Float!, $profile: String) {
          updateEmployee(id: $id, name: $name, email: $email, department: $department, position: $position, salary: $salary, profile: $profile) {
            id
          }
        }
      `,
      variables: emp
    });
  }

  deleteEmployee(id: string) {
    return this.apollo.mutate({
      mutation: gql`mutation ($id: ID!) { deleteEmployee(id: $id) { id } }`,
      variables: { id }
    });
  }

  searchEmployees(department: string, position: string) {
    return this.apollo.query({
      query: gql`
        query ($department: String, $position: String) {
          searchEmployees(department: $department, position: $position) {
            id name email department position salary profile
          }
        }
      `,
      variables: { department, position }
    });
  }
} 
