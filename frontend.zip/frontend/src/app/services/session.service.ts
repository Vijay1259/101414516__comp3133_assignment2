export class SessionService {
    static isLoggedIn(): boolean {
      return !!sessionStorage.getItem('token');
    }
  
    static logout(): void {
      sessionStorage.removeItem('token');
    }
  } 
