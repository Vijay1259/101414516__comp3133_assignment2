import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <h2>Login</h2>
      <form (ngSubmit)="login()">
        <input class="form-control mb-2" type="text" [(ngModel)]="email" name="email" placeholder="Email" required>
        <input class="form-control mb-2" type="password" [(ngModel)]="password" name="password" placeholder="Password" required>
        <button class="btn btn-primary" type="submit">Login</button>
        <a routerLink="/signup" class="btn btn-link">Sign up</a>
      </form>
    </div>
  `
})
export class LoginComponent {
  email = '';
  password = '';

  constructor(private router: Router) {}

  login() {
    if (this.email === 'admin@test.com' && this.password === '123') {
      sessionStorage.setItem('token', 'user-token');
      console.log('TOKEN SET:', sessionStorage.getItem('token'));
      this.router.navigate(['/employees']);
    } else {
      alert('Invalid credentials');
    }
  }
}