import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <h2>Sign Up</h2>
      <form (ngSubmit)="signup()">
        <input class="form-control mb-2" type="text" [(ngModel)]="email" name="email" placeholder="Email" required>
        <input class="form-control mb-2" type="password" [(ngModel)]="password" name="password" placeholder="Password" required>
        <button class="btn btn-success" type="submit">Sign Up</button>
        <a routerLink="/" class="btn btn-link">Login</a>
      </form>
    </div>
  `
})
export class SignupComponent {
  email = '';
  password = '';

  constructor(private router: Router) {}

  signup() {
    alert('Signup successful! Now login.');
    this.router.navigate(['/']);
  }
} 
